## About Me

Hi, My name is jan

### My APP

- Android
  1. [QR Scanner](https://play.google.com/store/apps/details?id=com.jan_null.qrscanner)

### Contact
- [Github](https://github.com/cendolinside123)
- [Twitter](https://twitter.com/IanRahasia?s=09)
- [facebook](https://www.facebook.com/ian.s.jr.9/)
